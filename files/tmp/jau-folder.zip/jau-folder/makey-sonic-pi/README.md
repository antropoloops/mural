# makey-sonic-pi
Control live-coding synth program Sonic Pi with a MaKey MaKey.
Instructions and video here:  [https://alcluith.wordpress.com/2018/01/25/sonic-pi-goes-bananas/](https://alcluith.wordpress.com/2018/01/25/sonic-pi-goes-bananas/)
